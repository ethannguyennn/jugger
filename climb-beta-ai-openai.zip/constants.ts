
export const LOADING_MESSAGES = [
  'Detecting the starting holds...',
  'Isolating your specified hold color...',
  'Gauging wall scale from hold spacing...',
  'Inferring climber height and reach...',
  'Maximizing hold usage for high-density beta...',
  'Enforcing strict 4-point contact rules...',
  'Analyzing for static stability...',
  'Calculating dynamic momentum paths...',
  'Chalking up the AI silhouette...',
  'Ensuring limbs stay off the wall surface...',
  'Rendering realistic bouldering movements...',
  'Almost to the top hold...',
  'Finalizing your personalized beta...'
];
