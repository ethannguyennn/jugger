import type { ClimbData } from '../types';
import { toBase64 } from '../utils/fileUtils';

type CreateResponse = { videoId: string };
type StatusResponse = { status: 'queued' | 'in_progress' | 'completed' | 'failed'; progress?: number; error?: { code?: string; message?: string } };

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Client-side helper:
 * 1) POST the image + climb options to our serverless API route
 * 2) Poll status until complete
 * 3) Download the mp4 via our serverless proxy (so the OpenAI key stays server-side)
 */
export const generateClimbingVideo = async (climbData: ClimbData): Promise<Blob> => {
  const { imageFile, color, style } = climbData;

  const imageBase64 = await toBase64(imageFile);

  // 1) Create generation job
  const createRes = await fetch('/api/generate-video', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      imageBase64,
      imageMimeType: imageFile.type,
      color,
      style,
    }),
  });

  if (!createRes.ok) {
    const txt = await createRes.text().catch(() => '');
    throw new Error(txt || `Failed to start generation (${createRes.status})`);
  }

  const { videoId } = (await createRes.json()) as CreateResponse;
  if (!videoId) throw new Error('No video id returned from server.');

  // 2) Poll status
  let status: StatusResponse['status'] = 'queued';
  for (;;) {
    await sleep(4000);

    const statusRes = await fetch(`/api/video-status?id=${encodeURIComponent(videoId)}`);
    if (!statusRes.ok) {
      const txt = await statusRes.text().catch(() => '');
      throw new Error(txt || `Failed to poll status (${statusRes.status})`);
    }

    const data = (await statusRes.json()) as StatusResponse;
    status = data.status;

    if (status === 'failed') {
      const msg = data.error?.message || 'Video generation failed.';
      throw new Error(msg);
    }

    if (status === 'completed') break;
  }

  // 3) Download content via server (keeps API key off the client)
  const contentRes = await fetch(`/api/video-content?id=${encodeURIComponent(videoId)}`);
  if (!contentRes.ok) {
    const txt = await contentRes.text().catch(() => '');
    throw new Error(txt || `Failed to download video (${contentRes.status})`);
  }

  return await contentRes.blob();
};
