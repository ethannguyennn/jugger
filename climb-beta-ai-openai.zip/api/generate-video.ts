import type { VercelRequest, VercelResponse } from '@vercel/node';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

const buildPrompt = (color: string, style: 'static' | 'dynamic') => {
  const styleInstruction =
    style === 'static'
      ? "STYLE: Static and controlled. The climber should move slowly and deliberately, maintaining body tension and minimizing swing. Movements should look graceful and precise."
      : "STYLE: Dynamic and flow-heavy. Use momentum to reach distant holds. Incorporate deadpoints and small explosive movements (dynos) where efficient. The climber should look powerful and fluid.";

  return `
TASK: Generate a high-precision bouldering beta video based STRICTLY on the provided image.
TARGET COLOR: ${color}
${styleInstruction}

CRITICAL RULES:
1. DO NOT CHANGE THE CLIMB:
   The layout of the wall and the positions of all holds must remain exactly as they appear in the source image. Do not add, remove, or move any holds.
2. FOUR POINTS OF CONTACT: The climber has four limbs: two hands and two feet.
3. EXCLUSIVE COLOR INTERACTION: All four points of contact (both hands and both feet) MUST ONLY touch the ${color} holds.
   - NEVER touch other hold colors.
   - NEVER touch the wall surface (no smearing).
   - Every move must result in a hand or foot landing precisely on a ${color} hold.
4. MANDATORY BOTTOM START:
   - Identify the absolute lowest holds of color ${color} in the image.
   - The video MUST start with the climber having both hands and both feet established on these lowest holds.
5. MAXIMIZE HOLD USAGE: Use as many of the ${color} holds as possible in the sequence. Do not skip holds unless absolutely necessary for a realistic movement flow.
6. SMART SCALE: Infer the size of the climber (height and reach) based on the distance between the ${color} holds in the image. A taller climber for wide gaps, a smaller climber for tight clusters.

VISUALS:
- Use a clean, solid dark silhouette for the climber.
- Ensure the animation is smooth and follows a logical bouldering progression from the starting bottom holds to the top-most finish hold.
`.trim();
};

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    res.status(405).send('Method not allowed');
    return;
  }
  if (!OPENAI_API_KEY) {
    res.status(500).send('Missing OPENAI_API_KEY on the server.');
    return;
  }

  try {
    const { imageBase64, imageMimeType, color, style } = (req.body || {}) as {
      imageBase64?: string;
      imageMimeType?: string;
      color?: string;
      style?: 'static' | 'dynamic';
    };

    if (!imageBase64 || !imageMimeType || !color || !style) {
      res.status(400).send('Missing required fields: imageBase64, imageMimeType, color, style');
      return;
    }

    const buf = Buffer.from(imageBase64, 'base64');
    const form = new FormData();
    form.append('prompt', buildPrompt(color, style));
    form.append('model', 'sora-2');
    form.append('seconds', '8');
    form.append('size', '1280x720');
    form.append('input_reference', new Blob([buf], { type: imageMimeType }), 'reference');

    const r = await fetch('https://api.openai.com/v1/videos', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${OPENAI_API_KEY}`,
      },
      body: form as any,
    });

    if (!r.ok) {
      const txt = await r.text().catch(() => '');
      res.status(r.status).send(txt || 'OpenAI video create failed');
      return;
    }

    const data = (await r.json()) as { id?: string };
    if (!data.id) {
      res.status(500).send('OpenAI returned no video id.');
      return;
    }

    res.status(200).json({ videoId: data.id });
  } catch (e: any) {
    console.error(e);
    res.status(500).send(e?.message || 'Server error');
  }
}
