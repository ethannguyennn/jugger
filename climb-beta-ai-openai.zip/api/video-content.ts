import type { VercelRequest, VercelResponse } from '@vercel/node';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'GET') {
    res.status(405).send('Method not allowed');
    return;
  }
  if (!OPENAI_API_KEY) {
    res.status(500).send('Missing OPENAI_API_KEY on the server.');
    return;
  }

  const id = (req.query?.id as string) || '';
  if (!id) {
    res.status(400).send('Missing id');
    return;
  }

  try {
    const r = await fetch(`https://api.openai.com/v1/videos/${encodeURIComponent(id)}/content`, {
      method: 'GET',
      headers: { Authorization: `Bearer ${OPENAI_API_KEY}` },
    });

    if (!r.ok || !r.body) {
      const txt = await r.text().catch(() => '');
      res.status(r.status || 500).send(txt || 'OpenAI content download failed');
      return;
    }

    // Pass through content type if available, otherwise assume mp4.
    res.setHeader('Content-Type', r.headers.get('content-type') || 'video/mp4');
    // Cache disabled (these are short-lived assets)
    res.setHeader('Cache-Control', 'no-store');

    // Stream response
    const arrayBuffer = await r.arrayBuffer();
    res.status(200).send(Buffer.from(arrayBuffer));
  } catch (e: any) {
    console.error(e);
    res.status(500).send(e?.message || 'Server error');
  }
}
