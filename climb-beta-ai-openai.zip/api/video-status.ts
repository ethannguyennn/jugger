import type { VercelRequest, VercelResponse } from '@vercel/node';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'GET') {
    res.status(405).send('Method not allowed');
    return;
  }
  if (!OPENAI_API_KEY) {
    res.status(500).send('Missing OPENAI_API_KEY on the server.');
    return;
  }

  const id = (req.query?.id as string) || '';
  if (!id) {
    res.status(400).send('Missing id');
    return;
  }

  try {
    const r = await fetch(`https://api.openai.com/v1/videos/${encodeURIComponent(id)}`, {
      method: 'GET',
      headers: { Authorization: `Bearer ${OPENAI_API_KEY}` },
    });

    if (!r.ok) {
      const txt = await r.text().catch(() => '');
      res.status(r.status).send(txt || 'OpenAI status fetch failed');
      return;
    }

    const data = await r.json();
    res.status(200).json({
      status: data.status,
      progress: data.progress,
      error: data.error,
    });
  } catch (e: any) {
    console.error(e);
    res.status(500).send(e?.message || 'Server error');
  }
}
