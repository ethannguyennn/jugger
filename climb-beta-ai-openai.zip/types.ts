
export type AppStatus = 'idle' | 'loading' | 'success' | 'error' | 'needs-key';

export interface ClimbData {
  imageFile: File;
  color: string;
  style: 'static' | 'dynamic';
}
