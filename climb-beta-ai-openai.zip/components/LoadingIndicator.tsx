
import React, { useState, useEffect } from 'react';
import { LOADING_MESSAGES } from '../constants';
import { JugLogo } from './JugLogo';

const LoadingIndicator: React.FC = () => {
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setMessageIndex((prevIndex) => (prevIndex + 1) % LOADING_MESSAGES.length);
    }, 3500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="text-center p-12 bg-white rounded-[30px] shadow-xl border-3 border-[#FED7AA]/30 animate-fade-in">
      <div className="relative inline-block mb-8">
        <div className="absolute inset-0 bg-orange-100 rounded-full animate-ping opacity-25"></div>
        <div className="relative">
          <JugLogo size={100} />
          <div className="absolute -bottom-2 -right-2">
            <svg className="animate-spin h-10 w-10 text-[#f97316]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          </div>
        </div>
      </div>
      <h2 className="text-2xl font-black text-gray-800 mb-4">generating your beta... ✨</h2>
      <div className="h-12 flex items-center justify-center">
        <p className="text-[#94a3b8] font-bold text-lg animate-pulse transition-opacity duration-500">
          {LOADING_MESSAGES[messageIndex]}
        </p>
      </div>
      <div className="mt-8 w-full bg-gray-100 h-3 rounded-full overflow-hidden">
        <div 
          className="h-full bg-gradient-to-r from-[#f97316] to-[#fb923c] transition-all duration-300" 
          style={{ width: `${((messageIndex + 1) / LOADING_MESSAGES.length) * 100}%` }}
        ></div>
      </div>
    </div>
  );
};

export default LoadingIndicator;
