
import React from 'react';
import { Sparkles, Camera } from 'lucide-react';

interface VideoResultProps {
  videoUrl: string;
  onReset: () => void;
}

const VideoResult: React.FC<VideoResultProps> = ({ videoUrl, onReset }) => {
  return (
    <div className="bg-white p-9 rounded-[30px] shadow-xl border-3 border-[#FED7AA]/30 space-y-8 animate-fade-in">
      <h3 className="text-2xl font-black text-gray-800 text-center">here's your beta! ✨</h3>
      
      <div className="relative rounded-[20px] overflow-hidden shadow-2xl bg-black aspect-video border-4 border-orange-50">
        <video
          src={videoUrl}
          controls
          autoPlay
          loop
          className="w-full h-full object-contain"
        >
          Your browser does not support the video tag.
        </video>
        <div className="absolute top-4 left-4 bg-orange-500 text-white text-xs font-black px-3 py-1 rounded-full shadow-lg">
          AI GENERATED
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="text-lg font-bold text-[#475569]">your sequence 🧗‍♀️</h4>
        <div className="p-5 bg-gradient-to-br from-[#d1fae5] to-[#a7f3d0] rounded-[18px] border-2 border-[#10b981] flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-[#10b981] text-white flex items-center justify-center font-black shadow-md">1</div>
          <div>
            <div className="font-bold text-gray-800">🟢 start here!</div>
            <div className="text-sm text-emerald-700">get comfy on those lowest holds</div>
          </div>
        </div>
        
        <div className="p-5 bg-gradient-to-br from-[#ffedd5] to-[#fed7aa] rounded-[18px] border-2 border-[#f97316] flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-[#f97316] text-white flex items-center justify-center font-black shadow-md">2</div>
          <div>
            <div className="font-bold text-gray-800">follow the color</div>
            <div className="text-sm text-orange-700">use as many holds as you need</div>
          </div>
        </div>

        <div className="p-5 bg-gradient-to-br from-[#fef3c7] to-[#fde68a] rounded-[18px] border-2 border-[#FFD700] flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-[#FFD700] text-white flex items-center justify-center font-black shadow-md">3</div>
          <div>
            <div className="font-bold text-gray-800">🏆 top it out!</div>
            <div className="text-sm text-amber-700">finish strong on the highest hold</div>
          </div>
        </div>
      </div>

      <button
        onClick={onReset}
        className="w-full py-4 bg-gradient-to-r from-[#94a3b8] to-[#64748b] text-white font-bold rounded-full text-lg shadow-lg hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2"
      >
        <Camera size={20} />
        try another route
      </button>
    </div>
  );
};

export default VideoResult;
