
import React, { useState, useCallback, useMemo } from 'react';
import type { ClimbData } from '../types';
import { Camera, Upload, Sparkles, Zap, Anchor } from 'lucide-react';

interface ClimbFormProps {
  onSubmit: (data: ClimbData) => void;
}

const ClimbForm: React.FC<ClimbFormProps> = ({ onSubmit }) => {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [color, setColor] = useState('');
  const [style, setStyle] = useState<'static' | 'dynamic'>('static');

  const holdColors = [
    { name: 'Green', hex: '#10b981' },
    { name: 'Blue', hex: '#3b82f6' },
    { name: 'Red', hex: '#ef4444' },
    { name: 'Yellow', hex: '#fbbf24' },
    { name: 'Orange', hex: '#f97316' },
    { name: 'Purple', hex: '#a855f7' },
    { name: 'Pink', hex: '#ec4899' },
    { name: 'White', hex: '#ffffff' },
    { name: 'Black', hex: '#1f2937' }
  ];

  const isFormValid = useMemo(() => {
    return imageFile && color.trim().length > 0;
  }, [imageFile, color]);

  const handleImageChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  }, []);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    if (isFormValid && imageFile) {
      onSubmit({ imageFile, color, style });
    }
  }, [isFormValid, onSubmit, imageFile, color, style]);

  return (
    <form onSubmit={handleSubmit} className="bg-white p-9 rounded-[30px] shadow-xl border-3 border-[#FED7AA]/30 space-y-8 animate-fade-in">
      {!imagePreview ? (
        <div className="text-center">
          <div 
            className="border-3 border-dashed border-[#fdba74] rounded-[25px] p-16 mb-5 bg-gradient-to-br from-[#FFFBF5] to-[#FFF7ED] cursor-pointer hover:bg-[#FFF7ED] transition-all"
            onClick={() => document.getElementById('image-upload')?.click()}
          >
            <Camera size={72} className="mx-auto text-[#f97316]/80 mb-5" />
            <h3 className="text-2xl font-bold text-gray-800 mb-3">snap your wall! 📸</h3>
            <p className="text-gray-500 mb-6 leading-relaxed">
              upload a pic of your climbing wall<br/>
              <span className="text-sm">and let's find your route together</span>
            </p>
            <div className="inline-flex items-center px-9 py-4 bg-gradient-to-r from-[#f97316] to-[#fb923c] text-white font-bold rounded-full shadow-lg shadow-orange-500/30">
              <Upload size={20} className="mr-2" />
              choose photo
            </div>
            <input id="image-upload" type="file" className="sr-only" accept="image/*" onChange={handleImageChange} />
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          <div>
            <h3 className="text-xl font-bold text-gray-800 mb-4">how do you wanna find it? 🤔</h3>
            <div className="relative rounded-[20px] overflow-hidden shadow-lg border-2 border-orange-100">
              <img src={imagePreview} alt="Preview" className="w-full h-auto block" />
              <div 
                className="absolute inset-0 bg-black/20 opacity-0 hover:opacity-100 flex items-center justify-center transition-opacity cursor-pointer"
                onClick={() => document.getElementById('image-upload')?.click()}
              >
                <span className="bg-white text-[#f97316] px-4 py-2 rounded-full font-bold shadow-md">change image</span>
              </div>
              <input id="image-upload" type="file" className="sr-only" accept="image/*" onChange={handleImageChange} />
            </div>
          </div>

          <div>
            <label className="block text-gray-700 font-bold mb-4">pick your hold color! 🎨</label>
            <div className="flex gap-2 flex-wrap justify-center mb-6">
              {holdColors.map((c) => (
                <button
                  key={c.hex}
                  type="button"
                  onClick={() => setColor(c.name)}
                  className={`w-14 h-14 rounded-2xl border-3 transition-all transform hover:scale-110 active:scale-95 ${color.toLowerCase() === c.name.toLowerCase() ? 'border-[#f97316] shadow-lg shadow-orange-200' : 'border-gray-100 shadow-sm'}`}
                  style={{ backgroundColor: c.hex }}
                  title={c.name}
                >
                  {color.toLowerCase() === c.name.toLowerCase() && (
                    <div className="mx-auto w-6 h-6 bg-[#f97316] rounded-full flex items-center justify-center text-white text-xs">✓</div>
                  )}
                </button>
              ))}
            </div>
            
            <input
              type="text"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              placeholder="or type color here (e.g. Neon Pink)"
              className="w-full py-4 px-6 bg-gray-50 border-2 border-gray-100 rounded-[20px] focus:outline-none focus:border-[#f97316] transition-all font-medium text-gray-700"
            />
          </div>

          <div>
            <label className="block text-gray-700 font-bold mb-4">climbing style! 🧗</label>
            <div className="grid grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setStyle('static')}
                className={`p-4 rounded-[20px] border-2 transition-all flex flex-col items-center gap-2 ${style === 'static' ? 'border-[#f97316] bg-[#FFF7ED] text-[#f97316]' : 'border-gray-100 bg-gray-50 text-gray-400'}`}
              >
                <Anchor size={28} />
                <span className="font-bold">static</span>
                <span className="text-[10px] text-center opacity-70">slow, controlled, graceful</span>
              </button>
              <button
                type="button"
                onClick={() => setStyle('dynamic')}
                className={`p-4 rounded-[20px] border-2 transition-all flex flex-col items-center gap-2 ${style === 'dynamic' ? 'border-[#f97316] bg-[#FFF7ED] text-[#f97316]' : 'border-gray-100 bg-gray-50 text-gray-400'}`}
              >
                <Zap size={28} />
                <span className="font-bold">dynamic</span>
                <span className="text-[10px] text-center opacity-70">explosive, flow, momentum</span>
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={!isFormValid}
            className="w-full py-4 bg-gradient-to-r from-[#f97316] to-[#fb923c] text-white font-bold rounded-full text-lg shadow-lg shadow-orange-500/30 disabled:opacity-50 disabled:cursor-not-allowed hover:scale-[1.02] active:scale-95 transition-all"
          >
            <Sparkles size={22} className="inline mr-2" />
            find my route!
          </button>
        </div>
      )}
    </form>
  );
};

export default ClimbForm;
