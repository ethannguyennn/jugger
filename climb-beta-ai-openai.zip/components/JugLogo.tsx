
import React from 'react';

export const JugLogo: React.FC<{ size?: number }> = ({ size = 48 }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{ display: 'inline-block' }}>
    <ellipse cx="50" cy="55" rx="35" ry="30" fill="#fdba74" stroke="#f97316" strokeWidth="3"/>
    <ellipse cx="50" cy="45" rx="30" ry="25" fill="#fed7aa"/>
    <path d="M 30 45 Q 50 35 70 45" fill="none" stroke="#f97316" strokeWidth="2"/>
    <circle cx="40" cy="50" r="3" fill="#ea580c"/>
    <circle cx="60" cy="50" r="3" fill="#ea580c"/>
    <path d="M 42 60 Q 50 65 58 60" fill="none" stroke="#ea580c" strokeWidth="2" strokeLinecap="round"/>
    <circle cx="75" cy="30" r="2" fill="#FFD700"/>
    <circle cx="25" cy="35" r="1.5" fill="#FFD700"/>
  </svg>
);
