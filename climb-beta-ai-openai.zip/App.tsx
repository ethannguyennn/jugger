
import React, { useState, useCallback } from 'react';
import type { AppStatus, ClimbData } from './types';
import { generateClimbingVideo } from './services/openaiService';
import { JugLogo } from './components/JugLogo';
import ClimbForm from './components/ClimbForm';
import LoadingIndicator from './components/LoadingIndicator';
import VideoResult from './components/VideoResult';

const App: React.FC = () => {
  const [status, setStatus] = useState<AppStatus>('idle');
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);    setStatus('idle');
  };

  const handleFormSubmit = useCallback(async (climbData: ClimbData) => {
    setStatus('loading');
    setError(null);
    setVideoUrl(null);
    try {
      const videoBlob = await generateClimbingVideo(climbData);
      const objectUrl = URL.createObjectURL(videoBlob);
      
      setVideoUrl(objectUrl);
      setStatus('success');
    } catch (err: any) {
      console.error(err);
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
        setError(errorMessage);
        setStatus('error');
      }
    }
  }, []);

  const handleReset = useCallback(() => {
    setStatus('idle');
    setVideoUrl(null);
    setError(null);
    if(videoUrl) URL.revokeObjectURL(videoUrl);
  }, [videoUrl]);

  const renderContent = () => {
    switch (status) {
      case 'loading':
        return <LoadingIndicator />;
      case 'success':
        return videoUrl ? <VideoResult videoUrl={videoUrl} onReset={handleReset} /> : <p>oops!</p>;
      case 'error':
        return (
          <div className="text-center p-12 bg-white rounded-[30px] shadow-xl">
            <h2 className="text-2xl font-bold text-red-500 mb-4">uh oh! it failed 🏔️</h2>
            <p className="text-gray-500 mb-8">{error}</p>
            <button
              onClick={handleReset}
              className="px-8 py-4 bg-gray-100 text-gray-700 font-bold rounded-full hover:bg-gray-200 transition-all"
            >
              try again
            </button>
          </div>
        );
      case 'idle':
      default:
        return <ClimbForm onSubmit={handleFormSubmit} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF7ED] via-[#FFEDD5] to-[#FED7AA] p-5">
      <div className="max-w-[900px] mx-auto pt-10 pb-20">
        {/* Header */}
        <header className="text-center mb-8 animate-fade-in overflow-visible">
          <div className="mb-4">
            <JugLogo size={80} />
          </div>
          <h1 className="text-6xl md:text-7xl font-black bg-gradient-to-br from-[#f97316] via-[#fb923c] to-[#fdba74] bg-clip-text text-transparent tracking-tight py-2 leading-tight">
            jugger
          </h1>
          <p className="text-xl text-[#94a3b8] font-medium mt-1">
            climb smarter, not harder 🧗‍♀️✨
          </p>
        </header>

        {/* Mode Selector - Visual Only to match user UI */}
        <div className="flex gap-3 mb-6 justify-center animate-fade-in">
          <button 
            disabled 
            className={`px-7 py-3 rounded-full font-bold text-sm transition-all shadow-md ${status === 'idle' ? 'bg-gradient-to-r from-[#f97316] to-[#fb923c] text-white' : 'bg-white text-gray-400'}`}
          >
            📸 capture
          </button>
          <button 
            disabled 
            className={`px-7 py-3 rounded-full font-bold text-sm transition-all shadow-md ${status === 'loading' ? 'bg-gradient-to-r from-[#f97316] to-[#fb923c] text-white' : 'bg-white text-gray-400'}`}
          >
            🔍 detect
          </button>
          <button 
            disabled 
            className={`px-7 py-3 rounded-full font-bold text-sm transition-all shadow-md ${status === 'success' ? 'bg-gradient-to-r from-[#f97316] to-[#fb923c] text-white' : 'bg-white text-gray-400'}`}
          >
            ✨ beta
          </button>
        </div>

        {/* Main Content */}
        <main className="animate-fade-in">
          {renderContent()}
        </main>

        {/* Info Footer */}
        <div className="mt-8 p-7 bg-gradient-to-br from-white to-[#FFF7ED] rounded-[25px] border-2 border-[#FED7AA]/20 shadow-sm animate-fade-in">
          <div className="flex items-center gap-3 mb-4">
            <JugLogo size={32} />
            <h4 className="text-xl font-bold text-gray-800">how jugger works</h4>
          </div>
          <div className="grid gap-3 text-gray-500 leading-relaxed">
            <p><span className="text-2xl mr-2">📸</span> <strong>snap it:</strong> upload a pic of your climbing wall</p>
            <p><span className="text-2xl mr-2">🎨</span> <strong>pick it:</strong> tell us which color to focus on</p>
            <p><span className="text-2xl mr-2">✨</span> <strong>crush it:</strong> follow the AI beta and send that route!</p>
          </div>
          <div className="mt-5 p-4 bg-gradient-to-br from-[#FFFBF5] to-[#FFF7ED] rounded-[15px] text-sm text-center border border-[#FED7AA] text-gray-500">
            <span className="text-lg mr-1">💡</span> <strong>pro tip:</strong> four points of contact will strictly use your color!
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
